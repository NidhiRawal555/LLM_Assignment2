"""
data.py
-------
Handles turning tokenized text into (x, y) training batches for
next-token prediction.

This assignment says to "use preprocessed dataset from Assignment 1
(tokenized and cleaned)". Since every student's Assignment 1 tokenizer
output looks a little different, this module supports THREE input shapes
so you can point it at whatever you already have:

  1. A .pt file containing a 1D torch.LongTensor of token ids
     -> data_path="data/assignment1_tokens.pt"
  2. A .npy file containing a 1D numpy array of token ids
     -> data_path="data/assignment1_tokens.npy"
  3. A plain .txt file of raw (already-cleaned) text
     -> data_path="data/assignment1_clean.txt"
     (a simple built-in character-level tokenizer is fit on it)

If none of the above exist, it falls back to a small bundled sample
corpus (data/sample_corpus.txt) purely so the pipeline is runnable
end-to-end out of the box. Replace this with your real Assignment 1
output before you write up results for the report.
"""

import os
import numpy as np
import torch


class CharTokenizer:
    """Minimal character-level tokenizer, used only as a fallback.

    Swap this out if Assignment 1 already produced a BPE/word-piece
    vocabulary and integer ids -- in that case just load the ids
    directly (see load_token_ids below) and skip this class entirely.
    """

    def __init__(self, text: str):
        chars = sorted(set(text))
        self.stoi = {ch: i for i, ch in enumerate(chars)}
        self.itos = {i: ch for i, ch in enumerate(chars)}
        self.vocab_size = len(chars)

    def encode(self, s: str):
        return [self.stoi[c] for c in s]

    def decode(self, ids):
        return "".join(self.itos[i] for i in ids)


def _ensure_sample_corpus(path: str):
    """Writes a tiny original placeholder corpus if nothing else is found,
    so the code always runs. This is NOT meant to stand in for your real
    Assignment 1 dataset -- it exists only so train.py never crashes on
    a fresh checkout."""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if os.path.exists(path):
        return
    placeholder = (
        "this is a small placeholder corpus used only to verify that the "
        "training pipeline runs end to end. replace this file, or better, "
        "point config.data_path at your real assignment one output, "
        "before you record any results for your report. a transformer "
        "learns to predict the next token in a sequence by attending to "
        "the tokens that came before it. training on this placeholder "
        "text will not produce meaningful language modeling results, it "
        "only exercises the code path. " * 40
    )
    with open(path, "w") as f:
        f.write(placeholder)


def load_token_ids(cfg) -> (torch.Tensor, int):
    """Returns (all_token_ids as 1D LongTensor, vocab_size)."""
    path = cfg.data_path

    if path.endswith(".pt") and os.path.exists(path):
        ids = torch.load(path)
        if not torch.is_tensor(ids):
            ids = torch.tensor(ids, dtype=torch.long)
        vocab_size = int(ids.max().item()) + 1
        return ids.long(), vocab_size

    if path.endswith(".npy") and os.path.exists(path):
        arr = np.load(path)
        ids = torch.tensor(arr, dtype=torch.long)
        vocab_size = int(ids.max().item()) + 1
        return ids, vocab_size

    if path.endswith(".txt") and os.path.exists(path):
        with open(path, "r") as f:
            text = f.read()
        tok = CharTokenizer(text)
        ids = torch.tensor(tok.encode(text), dtype=torch.long)
        return ids, tok.vocab_size

    # Nothing found -> fall back to bundled sample corpus.
    _ensure_sample_corpus(cfg.fallback_raw_text_path)
    with open(cfg.fallback_raw_text_path, "r") as f:
        text = f.read()
    tok = CharTokenizer(text)
    ids = torch.tensor(tok.encode(text), dtype=torch.long)
    print(
        f"[data.py] WARNING: '{cfg.data_path}' not found. Using bundled "
        f"placeholder corpus at '{cfg.fallback_raw_text_path}' instead. "
        f"Point cfg.data_path at your real Assignment 1 output before "
        f"you record results for the report."
    )
    return ids, tok.vocab_size


def make_splits(ids: torch.Tensor, val_fraction: float = 0.1):
    n = len(ids)
    n_val = int(n * val_fraction)
    train_ids = ids[: n - n_val]
    val_ids = ids[n - n_val:]
    return train_ids, val_ids


def get_batch(data: torch.Tensor, batch_size: int, block_size: int, device: str):
    """Randomly samples `batch_size` chunks of length `block_size` and
    builds (x, y) pairs for next-token prediction: y is x shifted by one."""
    ix = torch.randint(len(data) - block_size - 1, (batch_size,))
    x = torch.stack([data[i: i + block_size] for i in ix])
    y = torch.stack([data[i + 1: i + block_size + 1] for i in ix])
    return x.to(device), y.to(device)
